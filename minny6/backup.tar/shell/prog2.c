char s[20]="Shell Programming";

main()
{
	printf("%s\n",s);
}
