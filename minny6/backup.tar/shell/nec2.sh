#!/bin/sh

food=Apple
echo "私は${food}が好きです"
echo "${food}はとてもおいしいです。"

