main()
{
	int  n;
	n=100;
	printf("n --> %d\n",n);
}

