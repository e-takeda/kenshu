#!/bin/sh

echo '('1')'date
echo '('2')'who
echo '('3')'pwd
echo '('4')'ls -l 
