#! /bin/sh


echo 'Hello'
echo 'my name is Eri.'
