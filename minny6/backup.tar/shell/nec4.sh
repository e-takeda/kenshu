#!/bin/sh

echo -n 'お名前は？'
read name
echo -n '出身は？'
read from
echo "${name}さんは${from}さんの出身です。"
