main()
{
	char   a;
	int    b;
	float  c;
	double d;

	a='A';
	b=100;
	c=0.123;
	d=1234.567;

	printf("%c %d %f %f\n",a,b,c,d);
}


